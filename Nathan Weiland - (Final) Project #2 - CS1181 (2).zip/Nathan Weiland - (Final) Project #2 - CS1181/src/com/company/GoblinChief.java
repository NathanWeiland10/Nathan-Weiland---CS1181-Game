package com.company;

import javax.swing.*;
class GoblinChief extends Enemy {

    public GoblinChief() {
        super.setName("Goblin Chief");
        super.setMaxHealth(150);
        super.setHealth(150);
        super.setDamage(25);
        super.setHitChance(60);
        super.setDodgeChance(5);
        super.setLootAmount(200);
        super.setLevelRangeMin(7);
        super.setLevelRangeMax(14);
        super.setXP(300);
        super.setDefence(14);
        super.setEncounterChance(35);

        super.setSpecialMoveChance(20);

        super.setPNGFileName("resource/Goblin Chief.png");
        super.setSpawnSoundFileName("resource/GoblinChiefSpawn.wav");
        super.setEnemyType("Goblin");

        super.setItemDropChance(10);

        super.setHealthPercentToFleeAt(0.1);
        super.setChanceToFlee(15);

        super.setItemDrop(new Item("Goblin Club", "Increases damage by by +11 when equipped", "Sword", 11, 0, 10));
    }

    public void specialMove(Player player, JTextArea out) {

        double damageToTake = (super.getDamage() * 2 ) - player.getPlayerDefence();

        if (damageToTake <= 0) {
            damageToTake = 1;
        }

        player.takeDamage(damageToTake);
        out.append("\n\nThe goblin chief bashed you for " + damageToTake + " damage!");
        PlaySound.play(player.getPlayerHurtSounds());

    }

}