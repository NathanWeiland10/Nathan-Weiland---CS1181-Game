package com.company;

import javax.swing.*;
class MetalSlime extends Enemy {

    public MetalSlime() {
        super.setName("Metal Slime");
        super.setMaxHealth(8);
        super.setHealth(8);
        super.setDamage(10);
        super.setHitChance(75);
        super.setDodgeChance(30);
        super.setLootAmount(150);
        super.setLevelRangeMin(2);
        super.setLevelRangeMax(9);
        super.setXP(500);
        super.setDefence(99);
        super.setEncounterChance(5);

        super.setSpecialMoveChance(20);

        super.setPNGFileName("resource/Metal Slime.png");
        super.setSpawnSoundFileName("resource/MetalSlimeSpawn.wav");
        super.setEnemyType("Slime");

        super.setItemDropChance(10);

        super.setHealthPercentToFleeAt(0.3);
        super.setChanceToFlee(35);

        super.setItemDrop(new Item("Pure Metal Sword", "Increases damage by +10 when equipped", "Weapon", 10, 0, 5));
    }

    public void specialMove(Player player, JTextArea out) {

        double damageToTake = 30 - player.getPlayerDefence();

        if (damageToTake <= 0) {
            damageToTake = 1;
        }

        player.takeDamage(damageToTake);
        out.append("\n\nThe metal slime hit you with a fireball for " + damageToTake + " damage!");
        PlaySound.play("resource/Fireball.wav");
        PlaySound.play(player.getPlayerHurtSounds());

    }

}