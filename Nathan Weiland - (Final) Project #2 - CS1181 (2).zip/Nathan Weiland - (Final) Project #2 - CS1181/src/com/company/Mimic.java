package com.company;

import javax.swing.*;
class Mimic extends Enemy {

    public Mimic() {
        super.setName("Mimic");
        super.setMaxHealth(45);
        super.setHealth(45);
        super.setDamage(12);
        super.setHitChance(60);
        super.setDodgeChance(20);
        super.setLootAmount(150);
        super.setLevelRangeMin(3);
        super.setLevelRangeMax(6);
        super.setXP(100);
        super.setDefence(5);
        super.setEncounterChance(30);
        super.setSpecialMoveChance(25);
        super.setPNGFileName("resource/Mimic.png");
        super.setSpawnSoundFileName("resource/MimicSpawn.wav");
        super.setEnemyType("Mimic");

        super.setItemDropChance(0);

        super.setHealthPercentToFleeAt(0.2);
        super.setChanceToFlee(20);

        super.setItemDrop(new Item("Mimic 'ChestPiece'", "Increases defence by +7 when equipped", "Breastplate", 7, 0, 5));
    }

    public void specialMove(Player player, JTextArea out) {

        out.append("\n\nThe mimic cursed you for 3 turns!");
        player.setStatusEffect(4, "Cursed");


    }

}