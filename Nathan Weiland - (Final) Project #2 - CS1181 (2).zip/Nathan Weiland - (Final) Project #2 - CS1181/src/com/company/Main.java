package com.company;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.DefaultCaret;
import java.awt.event.*;
import java.awt.*;
import java.io.*;
import java.util.*;

// *** Note for grader ***
// All custom assets for this project (images, sounds, etc) are located in the 'resource' folder
// Font used for text: "NSimSun"; program will still work / compile if font is not found / installed

class Main extends JFrame {

    // Class variables are used so they can be used throughout the code without values being reset / initialized multiple times:
    private static String name = "";
    private static Player player;

    private static boolean inBattle = false;
    private static boolean inShop = false;
    private static boolean isEquipping = false;
    private static boolean isUnequipping = false;
    private static boolean isRemoving = false;
    private static boolean inInn = false;
    private static boolean playerIsDead = false;

    private static ImageIcon image = new ImageIcon();
    private static JLabel imageLabel = new JLabel();
    private static ImageIcon smileyIcon = new ImageIcon();
    private static boolean willPressEnter = false;
    private static boolean hasPressedEnter = true;
    private static boolean battleIsOver = false;
    private static boolean playerFinishedTurn = false;
    private static String userDifficulty;
    private static Enemy encEnemy;
    private static Shop shop = new Shop();

    public Main() {

        // Player's initial difficulty is easy:
        player = new Player(name);
        userDifficulty = "Easy";

        JPanel root = new JPanel();
        root.setBackground(Color.black);

        Border greenBorder = BorderFactory.createLineBorder(Color.green);
        root.setLayout(new BorderLayout());
        root.setBorder(new EmptyBorder(10, 10, 10, 10));

        JPanel menuPanel = new JPanel();
        menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS));

        JPanel namePanel = new JPanel();
        namePanel.setBackground(Color.black);
        namePanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel nameLabel = new JLabel("Please Enter Your Name:");
        nameLabel.setFont(new Font("NSimSun", Font.BOLD, 24));
        nameLabel.setForeground(Color.green);
        nameLabel.setBackground(Color.black);
        namePanel.add(nameLabel);

        JTextField tf = new JTextField("");
        tf.setBorder(BorderFactory.createCompoundBorder(greenBorder, BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        tf.setFont(new Font("NSimSun", Font.BOLD, 24));
        tf.setBackground(Color.black);
        namePanel.add(tf);
        tf.setPreferredSize(new Dimension(300, 50));

        JButton confirmButton = new JButton("Confirm");
        confirmButton.setForeground(Color.green);
        confirmButton.setBackground(Color.black);
        confirmButton.setFont(new Font("NSimSun", Font.BOLD, 24));
        confirmButton.setBorder(BorderFactory.createCompoundBorder(greenBorder, BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        confirmButton.setPreferredSize(new Dimension(200,100));

        JPanel colorPanel = new JPanel();
        colorPanel.setBackground(Color.black);
        colorPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel colorLabel = new JLabel("What is your favorite color?:");
        colorLabel.setFont(new Font("NSimSun", Font.BOLD, 24));
        colorLabel.setForeground(Color.green);
        colorLabel.setBackground(Color.black);
        colorPanel.add(colorLabel);

        JTextField colortf = new JTextField("");
        colortf.setFont(new Font("NSimSun", Font.BOLD, 24));
        colortf.setBorder(BorderFactory.createCompoundBorder(greenBorder, BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        colortf.setForeground(Color.green);
        colortf.setCaretColor(Color.green);
        colortf.setBackground(Color.black);
        colorPanel.add(colortf);
        colortf.setPreferredSize(new Dimension(300, 50));

        colorLabel.setForeground(Color.green);
        nameLabel.setForeground(Color.green);
        tf.setForeground(Color.green);
        tf.setCaretColor(Color.green);
        confirmButton.setBorder(BorderFactory.createCompoundBorder(greenBorder, BorderFactory.createEmptyBorder(10, 10, 10, 10)));

        JButton colorButton = new JButton("Change");
        colorButton.setForeground(Color.green);
        colorButton.setBackground(Color.black);
        colorButton.setFont(new Font("NSimSun", Font.BOLD, 24));
        colorButton.setBorder(BorderFactory.createCompoundBorder(greenBorder, BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        colorPanel.add(colorButton);

        JPanel confirmPanel = new JPanel();
        confirmPanel.setBackground(Color.black);
        confirmPanel.add(confirmButton);

        JPanel difPanel = new JPanel();
        difPanel.setBackground(Color.black);

        JLabel smileyLabel = new JLabel();

        smileyIcon = new ImageIcon("resource/SmileIcon.png");
        smileyLabel.setIcon(smileyIcon);

        JLabel difLabel = new JLabel("Select your difficulty:");
        difLabel.setFont(new Font("NSimSun", Font.BOLD, 24));
        difLabel.setForeground(Color.green);
        difLabel.setBackground(Color.black);
        difPanel.add(difLabel);

        JButton easyButton = new JButton("Easy");
        easyButton.setPreferredSize(new Dimension(125,50));
        easyButton.setBorder(BorderFactory.createCompoundBorder(greenBorder, BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        easyButton.setForeground(Color.green);
        easyButton.setBackground(Color.black);
        easyButton.setFont(new Font("NSimSun", Font.BOLD, 24));
        difPanel.add(easyButton);

        JButton regularButton = new JButton("Regular");
        regularButton.setPreferredSize(new Dimension(125,50));
        regularButton.setBorder(BorderFactory.createCompoundBorder(greenBorder, BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        regularButton.setForeground(Color.green);
        regularButton.setBackground(Color.black);
        regularButton.setFont(new Font("NSimSun", Font.BOLD, 24));
        difPanel.add(regularButton);

        JButton hardButton = new JButton("Hard");
        hardButton.setPreferredSize(new Dimension(125,50));
        hardButton.setBorder(BorderFactory.createCompoundBorder(greenBorder, BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        hardButton.setForeground(Color.green);
        hardButton.setBackground(Color.black);
        hardButton.setFont(new Font("NSimSun", Font.BOLD, 24));
        difPanel.add(hardButton);

        JButton veteranButton = new JButton("Veteran");
        veteranButton.setPreferredSize(new Dimension(125,50));
        veteranButton.setBorder(BorderFactory.createCompoundBorder(greenBorder, BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        veteranButton.setForeground(Color.green);
        veteranButton.setBackground(Color.black);
        veteranButton.setFont(new Font("NSimSun", Font.BOLD, 24));
        difPanel.add(veteranButton);

        difPanel.add(smileyLabel);

        menuPanel.add(namePanel);
        menuPanel.add(colorPanel);
        menuPanel.add(difPanel);
        menuPanel.add(confirmPanel);

        root.add(menuPanel, BorderLayout.NORTH);

        JPanel textPanelParent = new JPanel();
        textPanelParent.setLayout(new BorderLayout());

        JPanel userTextHolder = new JPanel();
        userTextHolder.setBackground(Color.black);
        userTextHolder.setLayout(new BoxLayout(userTextHolder, BoxLayout.Y_AXIS));

        JPanel userInpParent = new JPanel();
        userInpParent.setMaximumSize(new Dimension(420, 1));
        userInpParent.setLayout(new BoxLayout(userInpParent, BoxLayout.X_AXIS));
        userInpParent.setBackground(Color.black);

        JTextField userInp = new JTextField();
        userInp.setFont(new Font("NSimSun", Font.BOLD, 24));
        userInp.setBackground(Color.black);
        userInp.setForeground(Color.green);
        userInp.setCaretColor(Color.green);
        userInp.setBorder(BorderFactory.createCompoundBorder(greenBorder, BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        userInpParent.add(userInp);

        JPanel textOutParent = new JPanel();
        textOutParent.setBackground(Color.black);

        JTextArea outputText = new JTextArea(33, 30);
        outputText.setFont(new Font("NSimSun", Font.BOLD, 24));
        outputText.setBackground(Color.black);
        outputText.setForeground(Color.green);
        outputText.setCaretColor(Color.green);
        outputText.setBorder(BorderFactory.createCompoundBorder(greenBorder, BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        outputText.setLineWrap(true);
        outputText.setWrapStyleWord(true);
        outputText.setEditable(false);
        JScrollPane scrollOut = new JScrollPane(outputText, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        DefaultCaret scrollCaret = (DefaultCaret)outputText.getCaret();
        scrollCaret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

        outputText.setAutoscrolls(true);

        textOutParent.add(scrollOut);
        scrollOut.setBorder(greenBorder);
        scrollOut.setForeground(Color.green);
        scrollOut.getVerticalScrollBar().setBackground(Color.black);

        JPanel userPanelParent = new JPanel();
        userPanelParent.setLayout(new BorderLayout());

        JTextArea userPanelText = new JTextArea(33, 30);
        userPanelText.setFont(new Font("NSimSun", Font.BOLD, 24));
        userPanelText.setBackground(Color.black);
        userPanelText.setForeground(Color.green);
        userPanelText.setCaretColor(Color.green);
        userPanelText.setBorder(BorderFactory.createCompoundBorder(greenBorder, BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        userPanelText.setLineWrap(true);
        userPanelText.setWrapStyleWord(true);
        userPanelText.setEditable(false);
        userPanelParent.add(userPanelText);

        userTextHolder.add(textOutParent);
        userTextHolder.add(userInpParent);

        textPanelParent.add(userTextHolder);

        JPanel imagePanel = new JPanel();
        textOutParent.setBackground(Color.BLACK);

        imageLabel.setIcon(image);
        imagePanel.setForeground(Color.black);
        imagePanel.setBackground(Color.black);
        imagePanel.add(imageLabel);

        ScreenShaker shaker = new ScreenShaker(imagePanel);

        confirmButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                PlaySound.play("resource/Confirm.wav");
                name = tf.getText();
                player.setName(name);
                player.setDifficulty(userDifficulty);
                outputText.setText("Hello, " + name + "! In this game, you will will fight enemies to increase your level and purchase items from the shop to work your way through the ranks. For help / a list of commands, try typing 'help'.");
                root.remove(menuPanel);
                userPanelText.setText(player.toString());
                root.add(textPanelParent, BorderLayout.EAST);
                root.add(userPanelParent, BorderLayout.WEST);
                image = new ImageIcon("resource/Town.png");
                imageLabel.setIcon(image);
                root.add(imagePanel, BorderLayout.CENTER);
                root.validate();
                root.repaint();
            }
        });

        easyButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                smileyIcon = new ImageIcon("resource/SmileIcon.png");
                smileyLabel.setIcon(smileyIcon);
                userDifficulty = "Easy";
                if (player != null) {
                    player.setDifficulty("Easy");
                }
                PlaySound.play("resource/ButtonClick.wav");
            }
        });

        regularButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                smileyIcon = new ImageIcon("resource/RegularIcon.png");
                smileyLabel.setIcon(smileyIcon);
                userDifficulty = "Regular";
                if (player != null) {
                    player.setDifficulty("Regular");
                }
                PlaySound.play("resource/ButtonClick.wav");
            }
        });

        hardButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                smileyIcon = new ImageIcon("resource/AngryIcon.png");
                smileyLabel.setIcon(smileyIcon);
                userDifficulty = "Hard";
                if (player != null) {
                    player.setDifficulty("Hard");
                }
                PlaySound.play("resource/ButtonClick.wav");
            }
        });

        veteranButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                smileyIcon = new ImageIcon("resource/HollowedIcon.png");
                smileyLabel.setIcon(smileyIcon);
                userDifficulty = "Veteran";
                if (player != null) {
                    player.setDifficulty("Veteran");
                }
                PlaySound.play("resource/ButtonClick.wav");
            }
        });

        colorButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String choice = colortf.getText();
                Color userColor = Color.GREEN;
                if (choice.equalsIgnoreCase("red")) {
                    userColor = Color.red;
                    PlaySound.play("resource/ButtonClick2.wav");
                    colortf.setText("");
                } else if (choice.equalsIgnoreCase("orange")) {
                    userColor = Color.orange;
                    PlaySound.play("resource/ButtonClick2.wav");
                    colortf.setText("");
                } else if (choice.equalsIgnoreCase("yellow")) {
                    userColor = Color.yellow;
                    PlaySound.play("resource/ButtonClick2.wav");
                    colortf.setText("");
                } else if (choice.equalsIgnoreCase("green")) {
                    userColor = Color.green;
                    PlaySound.play("resource/ButtonClick2.wav");
                    colortf.setText("");
                } else if (choice.equalsIgnoreCase("blue")) {
                    userColor = Color.blue;
                    PlaySound.play("resource/ButtonClick2.wav");
                    colortf.setText("");
                } else if (choice.equalsIgnoreCase("cyan") || choice.equalsIgnoreCase("light blue")) {
                    userColor = Color.cyan;
                    PlaySound.play("resource/ButtonClick2.wav");
                    colortf.setText("");
                } else if (choice.equalsIgnoreCase("purple") || choice.equalsIgnoreCase("magenta")) {
                    userColor = Color.magenta;
                    PlaySound.play("resource/ButtonClick2.wav");
                    colortf.setText("");
                } else if (choice.equalsIgnoreCase("pink")) {
                    userColor = Color.pink;
                    PlaySound.play("resource/ButtonClick2.wav");
                    colortf.setText("");
                } else if (choice.equalsIgnoreCase("white")) {
                    userColor = Color.white;
                    PlaySound.play("resource/ButtonClick2.wav");
                    colortf.setText("");
                } else {
                    PlaySound.play("resource/Denied.wav");
                    colortf.setText("Unknown color");
                }
                Border textBorder = BorderFactory.createLineBorder(userColor);
                colorLabel.setForeground(userColor);
                nameLabel.setForeground(userColor);
                tf.setForeground(userColor);
                tf.setCaretColor(userColor);
                difLabel.setForeground(userColor);
                tf.setBorder(BorderFactory.createCompoundBorder(textBorder, BorderFactory.createEmptyBorder(10, 10, 10, 10)));
                colorButton.setForeground(userColor);
                colorButton.setBorder(BorderFactory.createCompoundBorder(textBorder, BorderFactory.createEmptyBorder(10, 10, 10, 10)));
                confirmButton.setForeground(userColor);
                confirmButton.setBorder(BorderFactory.createCompoundBorder(textBorder, BorderFactory.createEmptyBorder(10, 10, 10, 10)));
                colorLabel.setForeground(userColor);
                easyButton.setBorder(BorderFactory.createCompoundBorder(textBorder, BorderFactory.createEmptyBorder(10, 10, 10, 10)));
                easyButton.setForeground(userColor);
                regularButton.setBorder(BorderFactory.createCompoundBorder(textBorder, BorderFactory.createEmptyBorder(10, 10, 10, 10)));
                regularButton.setForeground(userColor);
                hardButton.setBorder(BorderFactory.createCompoundBorder(textBorder, BorderFactory.createEmptyBorder(10, 10, 10, 10)));
                hardButton.setForeground(userColor);
                veteranButton.setBorder(BorderFactory.createCompoundBorder(textBorder, BorderFactory.createEmptyBorder(10, 10, 10, 10)));
                veteranButton.setForeground(userColor);
                colortf.setBorder(BorderFactory.createCompoundBorder(textBorder, BorderFactory.createEmptyBorder(10, 10, 10, 10)));
                colortf.setForeground(userColor);
                colortf.setCaretColor(userColor);
                nameLabel.setForeground(userColor);
                userInp.setForeground(userColor);
                userInp.setCaretColor(userColor);
                userInp.setBorder(BorderFactory.createCompoundBorder(textBorder, BorderFactory.createEmptyBorder(10, 10, 10, 10)));
                outputText.setForeground(userColor);
                outputText.setCaretColor(userColor);
                outputText.setBorder(BorderFactory.createCompoundBorder(textBorder, BorderFactory.createEmptyBorder(10, 10, 10, 10)));
                scrollOut.setBorder(textBorder);
                scrollOut.setForeground(userColor);
                userPanelText.setForeground(userColor);
                userPanelText.setCaretColor(userColor);
                userPanelText.setBorder(BorderFactory.createCompoundBorder(textBorder, BorderFactory.createEmptyBorder(10, 10, 10, 10)));
            }
        });




        userInp.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                outputText.setAutoscrolls(true);

                // If statements are used to determine the player's location;
                // While loops will cause major issues with Java Swing
                if (!playerIsDead) {

                String com = userInp.getText();

                if (e.getKeyCode() == KeyEvent.VK_ENTER)

                    if (!inBattle && !inShop && !isEquipping && !isUnequipping && !isRemoving && !inInn) {

                        if (com.equalsIgnoreCase("help") || com.equalsIgnoreCase("commands") && e.getKeyCode() == KeyEvent.VK_ENTER) {
                            outputText.append(player.playerCommands());
                        } else if ((com.equalsIgnoreCase("fight") || com.equalsIgnoreCase("battle") && e.getKeyCode() == KeyEvent.VK_ENTER)) {
                            com = "";
                            inBattle = true;
                            ArrayList<Enemy> enemyList = new ArrayList<Enemy>();
                            ArrayList<Enemy> enemiesWithinLevel = new ArrayList<Enemy>();
                            enemyList.add(new Slime());
                            enemyList.add(new Goblin());
                            enemyList.add(new Mimic());
                            enemyList.add(new MetalSlime());
                            enemyList.add(new RedSlime());
                            enemyList.add(new YellowFairy());
                            enemyList.add(new Swordsman());
                            enemyList.add(new GoblinChief());

                            Collections.shuffle(enemyList);
                            encEnemy = enemyList.get(0);

                            for (Enemy enemy : enemyList) {
                                if ((enemy.getMinLevelAmount() <= player.getPlayerLevel()) && (enemy.getMaxLevelAmount() >= player.getPlayerLevel())) {
                                    enemiesWithinLevel.add(enemy);
                                }
                            }

                            // Only allow player in battle if enemies within the level range exist:
                            if (enemiesWithinLevel.size() == 0) {
                                // Player will be unable to battle if no enemies were found:
                                outputText.append("\n\nError: No more enemies within player level");
                                inBattle = false;
                            } else {
                                boolean hasFoundEnemy = false;
                                while (!hasFoundEnemy) {
                                    int enemyVal = -1;
                                    int hasEncounteredOne = 0;
                                    for (int i = 0; i < enemiesWithinLevel.size(); i++) {
                                        if (enemiesWithinLevel.get(i).tryEncounter()) {
                                            enemyVal = i;
                                            hasEncounteredOne++;
                                        }
                                    }
                                    if (hasEncounteredOne == 1) {
                                        encEnemy = enemiesWithinLevel.get(enemyVal);
                                        hasFoundEnemy = true;
                                    }
                                }

                                // Playing on 'hard' or 'veteran' difficulty will also increase enemy loot and experience drops:
                                if (player.getDifficulty().equalsIgnoreCase("Easy")) {
                                    encEnemy.setMaxHealth(encEnemy.getMaxHealth() * 1.0);
                                    encEnemy.setHealth(encEnemy.getCurrentHealth() * 1.0);
                                } else if (player.getDifficulty().equalsIgnoreCase("Regular")) {
                                    encEnemy.setMaxHealth(encEnemy.getMaxHealth() * 1.5);
                                    encEnemy.setHealth(encEnemy.getCurrentHealth() * 1.5);
                                } else if (player.getDifficulty().equalsIgnoreCase("Hard")) {
                                    encEnemy.setMaxHealth(encEnemy.getMaxHealth() * 2);
                                    encEnemy.setHealth(encEnemy.getCurrentHealth() * 2);
                                    encEnemy.setDefence(encEnemy.getDefence() * 1.5);
                                    encEnemy.setDamage(encEnemy.getDamage() * 1.5);
                                    encEnemy.setLootAmount(encEnemy.getLootAmount() * 3);
                                    encEnemy.setXP(encEnemy.getXP() * 2);
                                } else if (player.getDifficulty().equalsIgnoreCase("Veteran")) {
                                    encEnemy.setMaxHealth(encEnemy.getMaxHealth() * 3);
                                    encEnemy.setHealth(encEnemy.getCurrentHealth() * 3);
                                    encEnemy.setDefence(encEnemy.getDefence() * 2);
                                    encEnemy.setDamage(encEnemy.getDamage() * 2);
                                    encEnemy.setLootAmount(encEnemy.getLootAmount() * 5);
                                    encEnemy.setXP(encEnemy.getXP() * 3);
                                }

                                userPanelText.setText(player.toString() + encEnemy.toString() + "\n\nWhat would you like to do? Available options:\n" + "1: Attack\n" + "2: Spells\n" + "3: Flee");
                                outputText.append("\n\nYou encountered a wild " + encEnemy.getName().toLowerCase() + "!");
                                PlaySound.play(encEnemy.getSpawnSoundFileName());
                                image = new ImageIcon(encEnemy.getPNGFileName());
                                imageLabel.setIcon(image);
                            }

                        } else if (com.equalsIgnoreCase("shop") || com.equalsIgnoreCase("store") && e.getKeyCode() == KeyEvent.VK_ENTER) {
                            outputText.append("\n\nWelcome to the shop! To buy an item, enter the number in front of the item. To leave the store, type 'leave'.");
                            outputText.append(shop.listItems(outputText));
                            PlaySound.play("resource/EnterStore.wav");
                            inShop = true;
                        } else if (com.equalsIgnoreCase("inn") || com.equalsIgnoreCase("tavern") && e.getKeyCode() == KeyEvent.VK_ENTER) {
                            int goldCost = (player.getPlayerLevel() * 10) * 2;
                            outputText.append("\n\nWelcome to the inn! You can rest to restore your mana and health for " + goldCost + " gold by typing 'rest'. To leave the inn, type 'leave'.");
                            PlaySound.play("resource/EnterInn.wav");
                            inInn = true;
                        } else if (com.equalsIgnoreCase("autoscroll") || com.equalsIgnoreCase("scroll") && e.getKeyCode() == KeyEvent.VK_ENTER) {
                            // Issue can sometimes occur; autoscroll no longer works, so text is reset and autoscroll is renabled:
                            outputText.setText("Autoscroll has been enabled / fixed");
                            outputText.setAutoscrolls(true);
                        } else if (com.equalsIgnoreCase("menu") && e.getKeyCode() == KeyEvent.VK_ENTER) {
                            // Player's progress will be saved / not be reset:
                            root.add(menuPanel, BorderLayout.NORTH);
                            root.remove(textPanelParent);
                            root.remove(userPanelParent);
                            root.remove(imagePanel);
                            root.validate();
                            root.repaint();
                        } else if (com.equalsIgnoreCase("heal") || com.equalsIgnoreCase("recover") && e.getKeyCode() == KeyEvent.VK_ENTER) {

                            if (player.getSpells().contains("Heal") && (player.getCurrentPlayerHealth() != player.getMaxPlayerHealth() && (player.checkIfCanHeal(outputText))) && e.getKeyCode() == KeyEvent.VK_ENTER) {
                                player.heal();
                                outputText.append("\n\nYou have healed: HP: " + player.getCurrentPlayerHealth() + " / " + player.getMaxPlayerHealth());
                                userPanelText.setText(player.toString());
                            } else if (player.getSpells().contains("Heal") && (player.getCurrentPlayerHealth() == player.getMaxPlayerHealth()) && e.getKeyCode() == KeyEvent.VK_ENTER) {
                                outputText.append("\n\nYou are currently at maximum health: HP: " + player.getCurrentPlayerHealth() + " / " + player.getMaxPlayerHealth());
                            } else if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                                outputText.append("\n\nYou have not learned this spell yet.");
                            }

                        } else if (com.equalsIgnoreCase("fireball") && e.getKeyCode() == KeyEvent.VK_ENTER) {

                            if (player.getSpells().contains("fireball") && e.getKeyCode() == KeyEvent.VK_ENTER) {
                                outputText.append("\n\nYou cannot cast fireball right now; you are not in battle.");
                            } else if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                                outputText.append("\n\nYou have not learned this spell yet.");
                            }

                        } else if (com.equalsIgnoreCase("midheal") || com.equalsIgnoreCase("mid-heal") && e.getKeyCode() == KeyEvent.VK_ENTER) {

                            if (player.getSpells().contains("Mid-Heal") && (player.getCurrentPlayerHealth() != player.getMaxPlayerHealth() && (player.checkIfCanMidHeal(outputText))) && e.getKeyCode() == KeyEvent.VK_ENTER) {
                                player.midHeal();
                                outputText.append("\n\nYou have healed: HP: " + player.getCurrentPlayerHealth() + " / " + player.getMaxPlayerHealth());
                                userPanelText.setText(player.toString());
                            } else if (player.getSpells().contains("Mid-Heal") && (player.getCurrentPlayerHealth() == player.getMaxPlayerHealth()) && e.getKeyCode() == KeyEvent.VK_ENTER) {
                                outputText.append("\n\nYou are currently at maximum health: HP: " + player.getCurrentPlayerHealth() + " / " + player.getMaxPlayerHealth());
                            } else if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                                outputText.append("\n\nYou have not learned this spell yet.");
                            }

                        } else if (com.equalsIgnoreCase("blast") && e.getKeyCode() == KeyEvent.VK_ENTER) {

                            if (player.getSpells().contains("blast") && e.getKeyCode() == KeyEvent.VK_ENTER) {
                                outputText.append("\n\nYou cannot cast blast right now; you are not in battle.");
                            } else if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                                outputText.append("\n\nYou have not learned this spell yet.");
                            }

                        } else if (com.equalsIgnoreCase("remove") && e.getKeyCode() == KeyEvent.VK_ENTER) {
                            isRemoving = true;

                            if (player.getInventory().size() == 0) {
                                outputText.append("\n\nYou have no items in your inventory to remove!");
                                isRemoving = false;
                            } else {
                                outputText.append("\n\nPlease enter the number next to the item you would like to remove, or type return if you no longer wish to remove an item:\n");
                                outputText.append(player.equipToString());
                            }
                        } else if (com.equalsIgnoreCase("equip") && e.getKeyCode() == KeyEvent.VK_ENTER) {
                            isEquipping = true;

                            if (player.getInventory().size() == 0) {
                                outputText.append("\n\nYou have no items in your inventory to equip!");
                                isEquipping = false;
                            } else {
                                outputText.append("\n\nPlease enter the number next to the item you would like to equip, or type return if you no longer wish to equip an item:\n");
                                outputText.append(player.equipToString());
                            }

                        } else if (com.equalsIgnoreCase("unequip") && e.getKeyCode() == KeyEvent.VK_ENTER) {
                            isUnequipping = true;

                            if (player.getEquippedItems().size() == 0) {
                                outputText.append("\n\nYou have no items to unequip!");
                                isUnequipping = false;
                            } else {
                                outputText.append("\n\nPlease enter the number next to the item you would like to unequip, or type return if you no longer wish to unequip an item:\n");
                                outputText.append(player.UnequipToString());
                            }

                        } else if (com.equalsIgnoreCase("inventory") && e.getKeyCode() == KeyEvent.VK_ENTER) {
                            outputText.append("\n\n" + player.checkInventory());
                        } else if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                            outputText.append("\n\nUnknown command");
                        }

                        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                            userInp.setText("");
                        }
                    }

                if (isRemoving) {

                    boolean foundItem = false;

                    // For loop to set up and determine player's items to remove:
                    for (int i = 0; i < player.getInventory().size(); i++) {
                        if (com.equalsIgnoreCase(String.valueOf(i)) && e.getKeyCode() == KeyEvent.VK_ENTER) {
                            player.removeItem(player.getInventory().get(i), outputText);
                            userPanelText.setText(player.toString());
                            foundItem = true;
                            isRemoving = false;
                        }
                    }
                    if (com.equalsIgnoreCase("list") && e.getKeyCode() == KeyEvent.VK_ENTER) {

                        outputText.append("\n\nPlease enter the number next to the item you would like to remove, or type return if you no longer wish to remove an item:\n");

                        if (player.getInventory().size() == 0) {
                            outputText.append("\n\nYou have no items in your inventory to remove!");
                            isRemoving = false;
                        } else {
                            outputText.append("\n\nPlease enter the number next to the item you would like to remove, or type return if you no longer wish to remove an item:\n");
                            outputText.append(player.equipToString());
                        }

                    } else if ((com.equalsIgnoreCase("exit") || com.equalsIgnoreCase("leave") || com.equalsIgnoreCase("quit") || com.equalsIgnoreCase("back") || com.equalsIgnoreCase("return") && e.getKeyCode() == KeyEvent.VK_ENTER)) {
                        outputText.append("\n\nYou have stopped removing items.");
                        isRemoving = false;
                    } else if (e.getKeyCode() == KeyEvent.VK_ENTER && !com.isEmpty() && !com.equalsIgnoreCase("remove") && !foundItem) {
                        outputText.append("\n\nCannot find item");
                    }
                    if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                        userInp.setText("");
                    }

                }

                if (isEquipping) {

                    boolean foundItem = false;

                    // For loop for to set up and determine player's items to equip:
                    for (int i = 0; i < player.getInventory().size(); i++) {
                        if (com.equalsIgnoreCase(String.valueOf(i)) && e.getKeyCode() == KeyEvent.VK_ENTER) {
                            player.equipItem(player.getInventory().get(i), outputText);
                            userPanelText.setText(player.toString());
                            foundItem = true;
                            PlaySound.play("resource/Equip.wav");
                            isEquipping = false;
                        }
                    }
                    if (com.equalsIgnoreCase("list") && e.getKeyCode() == KeyEvent.VK_ENTER) {

                        outputText.append("\n\nPlease enter the number next to the item you would like to equip, or type return if you no longer wish to equip an item:\n");

                        if (player.getInventory().size() == 0) {
                            outputText.append("\n\nYou have no items in your inventory to equip!");
                            isEquipping = false;
                        } else {
                            outputText.append("\n\nPlease enter the number next to the item you would like to equip, or type return if you no longer wish to equip an item:\n");
                            outputText.append(player.equipToString());
                        }

                    } else if ((com.equalsIgnoreCase("exit") || com.equalsIgnoreCase("leave") || com.equalsIgnoreCase("quit") || com.equalsIgnoreCase("back") || com.equalsIgnoreCase("return") && e.getKeyCode() == KeyEvent.VK_ENTER)) {
                        outputText.append("\n\nYou have stopped equipping items.");
                        isEquipping = false;
                    } else if (e.getKeyCode() == KeyEvent.VK_ENTER && !com.isEmpty() && !com.equalsIgnoreCase("equip") && !foundItem) {
                        isEquipping = false;
                        outputText.append("\n\nCannot find item");
                    }
                    if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                        userInp.setText("");
                    }


                }

                if (isUnequipping) {

                    boolean foundItem = false;

                    // For loop for to set up and determine player's items to unequip:
                    for (int i = 0; i < player.getEquippedItems().size(); i++) {
                        if (com.equalsIgnoreCase(String.valueOf(i)) && e.getKeyCode() == KeyEvent.VK_ENTER) {
                            isUnequipping = false;
                            player.unequipItem(player.getEquippedItems().get(i), outputText);
                            userPanelText.setText(player.toString());
                            PlaySound.play("resource/Equip.wav");
                            foundItem = true;
                        }
                    }

                    if (com.equalsIgnoreCase("list") && e.getKeyCode() == KeyEvent.VK_ENTER) {

                        outputText.append("\n\nPlease enter the number next to the item you would like to unequip, or type return if you no longer wish to unequip an item:\n");

                        if (player.getEquippedItems().size() == 0) {
                            outputText.append("\n\nYou have no items in your inventory to equip!");
                            isUnequipping = false;
                        } else {
                            outputText.append("\n\nPlease enter the number next to the item you would like to unequip, or type return if you no longer wish to unequip an item:\n");
                            outputText.append(player.UnequipToString());
                        }

                    } else if ((com.equalsIgnoreCase("exit") || com.equalsIgnoreCase("leave") || com.equalsIgnoreCase("quit") || com.equalsIgnoreCase("back") || com.equalsIgnoreCase("return") && e.getKeyCode() == KeyEvent.VK_ENTER)) {
                        outputText.append("\n\nYou have stopped unequipping items.");
                        isUnequipping = false;
                    } else if (e.getKeyCode() == KeyEvent.VK_ENTER && !com.isEmpty() && !com.equalsIgnoreCase("unequip") && !foundItem) {
                        outputText.append("\n\nCannot find item");
                        isUnequipping = false;
                    }
                    if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                        userInp.setText("");
                    }

                }

                if (inBattle) {

                    boolean playerTurn = true;
                    boolean enemyIsDead = false;

                    if (e.getKeyCode() == KeyEvent.VK_ENTER)

                        if (!willPressEnter) {

                            if (encEnemy.getCurrentHealth() >= 0 && player.getCurrentPlayerHealth() >= 0 && inBattle) {

                                if (com.equalsIgnoreCase("attack") || com.equalsIgnoreCase("1") || com.equalsIgnoreCase("fight") || com.equalsIgnoreCase("battle") && e.getKeyCode() == KeyEvent.VK_ENTER) {
                                    player.hit(encEnemy, outputText, shaker);
                                    playerTurn = false;
                                    player.advanceTurn();
                                } else if (com.equalsIgnoreCase("spells") || com.equalsIgnoreCase("2") && e.getKeyCode() == KeyEvent.VK_ENTER) {
                                    outputText.append(player.checkSpells());
                                } else if (com.equalsIgnoreCase("flee") || com.equalsIgnoreCase("3") && e.getKeyCode() == KeyEvent.VK_ENTER) {

                                    if (player.playerTryFlee()) {
                                        image = new ImageIcon();
                                        imageLabel.setIcon(image);
                                        outputText.append("\n\nYou have fled the battle successfully!\n\nPress enter to continue");
                                        PlaySound.play("resource/Flee.wav");
                                        battleIsOver = true;
                                        willPressEnter = true;
                                    } else {
                                        outputText.append("\n\nYou tried to flee, but failed!");
                                        playerTurn = false;
                                        player.advanceTurn();
                                    }

                                } else if (com.equalsIgnoreCase("heal") && e.getKeyCode() == KeyEvent.VK_ENTER) {

                                    if (player.getSpells().contains("Heal") && (player.getCurrentPlayerHealth() != player.getMaxPlayerHealth() && (player.checkIfCanHeal(outputText)))) {
                                        player.heal();
                                        outputText.append("\n\nYou have healed: HP: " + player.getCurrentPlayerHealth() + " / " + player.getMaxPlayerHealth());
                                        playerTurn = false;
                                        player.advanceTurn();
                                    } else if (player.getSpells().contains("Heal") && (player.getCurrentPlayerHealth() == player.getMaxPlayerHealth())) {
                                        outputText.append("\n\nYou are already at maximum health: " + player.getCurrentPlayerHealth() + " / " + player.getMaxPlayerHealth());
                                    } else if (!player.getSpells().contains("Heal")) {
                                        outputText.append("\n\nYou have not learned this spell yet.");
                                    }

                                } else if (com.equalsIgnoreCase("Fireball") && e.getKeyCode() == KeyEvent.VK_ENTER) {

                                    if (player.getSpells().contains("Fireball") && (player.checkIfCanFireball(outputText))) {
                                        player.fireball(encEnemy, outputText, shaker);
                                        playerTurn = false;
                                        player.advanceTurn();
                                    } else if (!player.getSpells().contains("Fireball")) {
                                        outputText.append("\n\nYou have not learned this spell yet.");
                                    }

                                } else if (com.equalsIgnoreCase("Blast") && e.getKeyCode() == KeyEvent.VK_ENTER) {

                                    if (player.getSpells().contains("Blast") && (player.checkIfCanBlast(outputText))) {
                                        player.blast(encEnemy, outputText, shaker);
                                        playerTurn = false;
                                        player.advanceTurn();
                                    } else if (!player.getSpells().contains("Blast")) {
                                        outputText.append("\n\nYou have not learned this spell yet.");
                                    }

                                } else if (com.equalsIgnoreCase("Midheal") || com.equalsIgnoreCase("Mid-Heal") && e.getKeyCode() == KeyEvent.VK_ENTER) {

                                    if (player.getSpells().contains("Mid-Heal") && (player.getCurrentPlayerHealth() != player.getMaxPlayerHealth() && (player.checkIfCanMidHeal(outputText)))) {
                                        player.midHeal();
                                        outputText.append("\n\nYou have healed: HP: " + player.getCurrentPlayerHealth() + " / " + player.getMaxPlayerHealth());
                                        playerTurn = false;
                                        player.advanceTurn();
                                    } else if (player.getSpells().contains("Mid-Heal") && (player.getCurrentPlayerHealth() == player.getMaxPlayerHealth())) {
                                        outputText.append("\n\nYou are already at maximum health: " + player.getCurrentPlayerHealth() + " / " + player.getMaxPlayerHealth());
                                    } else if (!player.getSpells().contains("Mid-Heal")) {
                                        outputText.append("\n\nYou have not learned this spell yet.");
                                    }

                                } else if (e.getKeyCode() == KeyEvent.VK_ENTER && !com.isEmpty()) {
                                    outputText.append("\n\nUnknown battle command");
                                }
                                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                                    userInp.setText("");
                                }

                            }

                            if (!playerTurn) {
                                player.takeStatusEffect(outputText);
                                userPanelText.setText(player.toString() + encEnemy.toString() + "\n\nWhat would you like to do? Available options:\n" + "1: Attack\n" + "2: Flee\n" + "3: Spells");
                                if (encEnemy.getCurrentHealth() <= 0) {
                                    enemyIsDead = true;
                                }
                            }

                            if (encEnemy.getCurrentHealth() >= 0 && player.getCurrentPlayerHealth() >= 0 && inBattle && !playerTurn && !enemyIsDead && ((encEnemy.getCurrentHealth() / encEnemy.getMaxHealth()) >= encEnemy.getHealthPercentToFleeAt())) {
                                if (encEnemy.trySpecialMove()) {
                                    encEnemy.specialMove(player, outputText);
                                        if (player.getCurrentPlayerHealth() <= 0) {
                                            outputText.append("\n\nYou have died!");
                                            playerIsDead = true;
                                            userInp.setEditable(false);
                                    }
                                } else {
                                    encEnemy.hit(player, outputText);
                                    if (player.getCurrentPlayerHealth() <= 0) {
                                        outputText.append("\n\nYou have died!");
                                        playerIsDead = true;
                                        userInp.setEditable(false);
                                    }
                                }

                                // User panel is set each time to update the player and enemies stats each time a turn is finished:
                                userPanelText.setText(player.toString() + encEnemy.toString() + "\n\nWhat would you like to do? Available options:\n" + "1: Attack\n" + "2: Flee\n" + "3: Spells");
                                playerTurn = true;

                            } else if (encEnemy.getCurrentHealth() >= 0 && player.getCurrentPlayerHealth() >= 0 && inBattle && !playerTurn && !enemyIsDead) {
                                if (encEnemy.tryFlee()) {
                                    image = new ImageIcon();
                                    imageLabel.setIcon(image);
                                    outputText.append("\n\nThe enemy fled successfully!\n\nPress enter to continue");
                                    PlaySound.play("resource/Flee.wav");
                                    battleIsOver = true;
                                    willPressEnter = true;
                                } else {
                                    outputText.append("\n\nThe enemy tried to flee, but failed!");
                                    playerTurn = true;
                                }

                            }

                            if (enemyIsDead) {

                                int lootDrop = encEnemy.getLootAmount();
                                if (player.getRingSlot().equalsIgnoreCase("Luxurious Ring")) {
                                    lootDrop = lootDrop * 2;
                                }

                                outputText.append("\n\nYou have won! You gained " + encEnemy.getXP() + "XP and " + lootDrop + " gold!\n\nPress enter to continue");
                                battleIsOver = true;
                                player.increaseMoney( encEnemy.getLootAmount());
                                if (encEnemy.tryItemDrop() && !player.getItemNames().contains(encEnemy.getItemDropName())) {
                                    encEnemy.dropItem(player, outputText);
                                }
                                player.increaseXP(encEnemy.getXP());
                                image = new ImageIcon();
                                imageLabel.setIcon(image);
                                willPressEnter = true;

                                if (player.getXpPUntilLevel() <= 0) {
                                    PlaySound.play("resource/LevelUp.wav");
                                    player.levelUp(outputText, shop);
                                }

                                userPanelText.setText(player.toString());
                            }
                        }

                    // Force player to press enter after completing a battle:
                    if (willPressEnter && e.getKeyCode() == KeyEvent.VK_ENTER && inBattle && !hasPressedEnter) {
                        player.resetTurn();
                        inBattle = false;
                        image = new ImageIcon("resource/Town.png");
                        userPanelText.setText(player.toString());
                        imageLabel.setIcon(image);
                        hasPressedEnter = true;
                        battleIsOver = false;
                        willPressEnter = false;
                        userInp.setText("");

                    }
                    if (battleIsOver) {
                        hasPressedEnter = false;
                    }

                }

                if (inShop) {

                    if (e.getKeyCode() == KeyEvent.VK_ENTER) {

                        image = new ImageIcon("resource/Shop.png");
                        imageLabel.setIcon(image);

                            // For loop to determine and set up the items currently in the shop:
                            for (int i = 0; i < shop.getItemsInShop().size(); i++) {
                                if (com.equalsIgnoreCase(String.valueOf(i)) && e.getKeyCode() == KeyEvent.VK_ENTER) {
                                    int cost = shop.getItemsInShop().get(i).getCost();
                                    if (player.getPlayerGold() >= cost) {
                                        if (shop.getItemsInShop().get(i).getLevelRequirement() <= player.getPlayerLevel()) {
                                            PlaySound.play("resource/Buy.wav");
                                            outputText.append("\n\nYou have bought the " + shop.getItemsInShop().get(i).getName() + "!");
                                            player.addToInventory(shop.getItemsInShop().get(i));
                                            player.changeGold(shop.getItemsInShop().get(i).getCost());
                                            shop.removeItem(i);
                                            userPanelText.setText(player.toString());
                                            outputText.append(shop.listItems(outputText));
                                        } else {
                                            outputText.append("\n\nYou are not a high enough level to buy this item!");
                                            PlaySound.play("resource/Denied.wav");
                                        }
                                    } else {
                                        outputText.append("\n\nYou cannot afford to buy the " + shop.getItemsInShop().get(i).getName());
                                        PlaySound.play("resource/Denied.wav");
                                    }
                                }
                            }
                            if (com.equalsIgnoreCase("exit") || com.equalsIgnoreCase("leave") || com.equalsIgnoreCase("quit") || com.equalsIgnoreCase("back") || com.equalsIgnoreCase("return") && e.getKeyCode() == KeyEvent.VK_ENTER) {
                                image = new ImageIcon("resource/Town.png");
                                imageLabel.setIcon(image);
                                outputText.append("\n\nYou have left the store.");
                                PlaySound.play("resource/LeaveStore.wav");
                                inShop = false;
                            } else if (com.equalsIgnoreCase("list") && e.getKeyCode() == KeyEvent.VK_ENTER) {
                                outputText.append(shop.listItems(outputText));
                            } else if (e.getKeyCode() == KeyEvent.VK_ENTER && !com.isEmpty() && !com.equalsIgnoreCase("shop") && !com.equalsIgnoreCase("store")) {
                                outputText.append("\n\nCannot find item / unknown command");
                            }
                            if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                                userInp.setText("");
                            }

                    }

                }

                if (inInn) {

                    if (e.getKeyCode() == KeyEvent.VK_ENTER) {

                        image = new ImageIcon("resource/Inn.png");
                        imageLabel.setIcon(image);

                        int sleepCost = (player.getPlayerLevel() * 10) * 2;

                        if (com.equalsIgnoreCase("rest") || com.equalsIgnoreCase("sleep") && e.getKeyCode() == KeyEvent.VK_ENTER) {
                            if (player.getPlayerGold() >= sleepCost) {
                                outputText.append("\n\nYou have rested; your health and mana have been fully restored");
                                player.changeGold(sleepCost);
                                player.setCurrentPlayerHealth(player.getMaxPlayerHealth());
                                player.setMaxPlayerMana(player.getMaxPlayerMana());
                                userPanelText.setText(player.toString());
                            } else {
                                outputText.append("\n\nYou do not have enough money!");
                            }
                        } else if (com.equalsIgnoreCase("exit") || com.equalsIgnoreCase("leave") || com.equalsIgnoreCase("quit") || com.equalsIgnoreCase("back") || com.equalsIgnoreCase("return") && e.getKeyCode() == KeyEvent.VK_ENTER) {
                            image = new ImageIcon("resource/Town.png");
                            imageLabel.setIcon(image);
                            outputText.append("\n\nYou have left the inn.");
                            PlaySound.play("resource/LeaveStore.wav");
                            inInn = false;
                        } else if (e.getKeyCode() == KeyEvent.VK_ENTER && !com.isEmpty() && !com.equalsIgnoreCase("inn") && !com.equalsIgnoreCase("tavern")) {
                            outputText.append("\n\nUnknown command");
                        }
                        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                            userInp.setText("");
                        }

                    }

                }


            }


            }

        });


        this.getContentPane().add(root);
        this.setTitle("Pixel RPG Game");
        this.setSize(500, 300);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.pack();
        this.setVisible(true);
    }

    public static void main(String[] args) throws FileNotFoundException {

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Main();
            }
        });
    }


}