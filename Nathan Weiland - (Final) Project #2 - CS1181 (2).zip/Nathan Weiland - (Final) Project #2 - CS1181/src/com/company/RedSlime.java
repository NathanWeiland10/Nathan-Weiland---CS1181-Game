package com.company;

import javax.swing.*;
class RedSlime extends Enemy {

    public RedSlime() {
        super.setName("Red Slime");
        super.setMaxHealth(30);
        super.setHealth(30);
        super.setDamage(10);
        super.setHitChance(65);
        super.setDodgeChance(20);
        super.setLootAmount(80);
        super.setLevelRangeMin(2);
        super.setLevelRangeMax(5);
        super.setXP(60);
        super.setDefence(4);
        super.setEncounterChance(40);
        super.setSpecialMoveChance(50);
        super.setPNGFileName("resource/Red Slime.png");
        super.setSpawnSoundFileName("resource/RedSlimeSpawn.wav");
        super.setEnemyType("Slime");

        super.setItemDropChance(10);

        super.setHealthPercentToFleeAt(0.3);
        super.setChanceToFlee(15);

        super.setItemDrop(new Item("Luxurious Ring", "Doubles the amount of gold dropped by enemies when equipped", "Ring", 1, 0, 1, "2x enemy gold drop"));
    }

    public void specialMove(Player player, JTextArea out) {

        double damageToTake = (super.getDamage() * 2 ) - player.getPlayerDefence();

        if (damageToTake <= 0) {
            damageToTake = 1;
        }

        player.takeDamage(damageToTake);
        out.append("\n\nThe red slime smothered you for " + damageToTake + " damage!");
        PlaySound.play(player.getPlayerHurtSounds());


    }

}